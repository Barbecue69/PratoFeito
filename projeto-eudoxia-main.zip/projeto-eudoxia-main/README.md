# Sobre Meu Projeto

Este projeto tem como objetivo oferecer soluções inovadoras para diminuir casos de despedicio de comida.

## Funcionalidades

- Cadastro de usuários
- Cadastro de empresas
- Dashboard interativo
- Desing simples e moderno

## Autores

- Braian Henrique Rodrigues Silva
- Matheus Costa Lustosa Carvalho Lacerda
- Hector Alejandro Perez Corniel
- Nelson de Almeida Sampaio
- Gustavo Galdino dos Santos

## O que você encontra aqui

Neste repositório você encontrará o código-fonte, documentação e exemplos de uso para todas as funcionalidades implementadas.   